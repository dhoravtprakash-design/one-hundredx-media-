ONE HUNDREDX MEDIA WEBSITE
===========================

Files:
- index.html
- assets/logo.png

Hostinger:
1. Open hPanel -> Websites -> Manage -> File Manager.
2. Open the website's public_html folder.
3. Upload index.html and the assets folder (including logo.png).
4. If an old index.html exists, replace it after backing it up.
5. Visit your domain.

The website is responsive for mobile and desktop.
Buttons are connected to:
- WhatsApp: +91 7016045125
- Instagram: @one_hundredx_media
- Creator Google Form: https://forms.gle/XjYqEQXoTwP7ndV97

Note: The page currently uses web-hosted Unsplash images for visual sections. You can replace them later with your own creator/campaign photos.
